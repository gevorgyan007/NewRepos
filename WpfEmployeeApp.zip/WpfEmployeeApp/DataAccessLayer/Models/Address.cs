﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Models
{
    public class Address
    {
        public string City { get; set; }
        public string HomeAddress { get; set; }
        public string WorkAddress { get; set; }
    }
}
