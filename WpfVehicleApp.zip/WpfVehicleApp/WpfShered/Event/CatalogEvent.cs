﻿using Prism.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfShered.EventModel;


namespace WpfShered.Event
{
    public class CatalogEvent : PubSubEvent<CatalogEventModel>
    {

    }
}
