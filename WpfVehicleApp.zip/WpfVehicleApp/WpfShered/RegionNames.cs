﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfShered
{
    public static class RegionNames
    {
        public static string TabRegion { get; set; } = nameof(TabRegion);
    }
}
